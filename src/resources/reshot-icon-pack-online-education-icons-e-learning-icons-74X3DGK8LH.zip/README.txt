This "Online Education Icons & E-learning Icons" icon pack was downloaded from https://www.reshot.com/free-svg-icons/pack/online-education-icons-e-learning-icons-74X3DGK8LH/ 

Please check the Reshot Icons license available at https://www.reshot.com/license/